package Com.TSL.LineEditorUtilities;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple LineEditor.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
